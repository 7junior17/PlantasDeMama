═══════════════════════════════════════════════
   APP PLANTAS MEDICINALES - TODOS LOS ARCHIVOS
═══════════════════════════════════════════════

📁 ESTRUCTURA DEL ZIP:

📂 Kotlin_Compose/
   ├── MainActivity.kt     ← Todas las pantallas en Compose
   └── Planta.kt           ← Modelo de datos + 10 plantas

📂 XML_Layouts/
   └── item_planta.xml     ← Tarjeta de cada planta

📂 XML_Values/
   └── colors.xml          ← Colores del diseño

📂 XML_Menu/
   └── bottom_nav_menu.xml ← Menú inferior

📂 Gradle/
   ├── libs.versions.toml          ← Versiones corregidas
   ├── build.gradle.kts_project    ← Gradle del proyecto
   └── build.gradle.kts_app        ← Gradle del módulo app

📂 Documentacion/
   └── Implementacion_App_Plantas.docx ← Documento completo

📂 Dashboard/
   └── dashboard-plantas-medicinales.html ← Análisis visual

📂 Guias/
   └── guia-firebase-setup.html ← Guía Firebase

═══════════════════════════════════════════════
NOTAS IMPORTANTES:
- Package name: com.example.plantas
- Minimum SDK: API 26 (Android 8.0)
- Lenguaje: Kotlin
- UI: Material Design 3
- Imágenes: locales en res/drawable
═══════════════════════════════════════════════
